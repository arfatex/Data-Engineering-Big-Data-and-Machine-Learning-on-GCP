describe trips;
select distinct(pickup_location_id) from trips;
#returns no data

