Loading Taxi Data into Google Cloud SQL
