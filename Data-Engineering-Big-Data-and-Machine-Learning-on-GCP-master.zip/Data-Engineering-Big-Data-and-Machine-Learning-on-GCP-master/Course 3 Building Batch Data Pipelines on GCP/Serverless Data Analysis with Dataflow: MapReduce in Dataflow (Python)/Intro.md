Objective
Identify Map and Reduce operations

Execute the pipeline

Use command line parameters
