Lab: Recommend products using Cloud SQL and SparkML
In this lab, you populate rentals data in Cloud SQL for the rentals recommendation engine to use. The recommendations engine itself will run on Dataproc using Spark ML.
Create Cloud SQL instance
Create database tables by importing .sql files from Cloud Storage
Populate the tables by importing .csv files from Cloud Storage
Allow access to Cloud SQL
Explore the rentals data using SQL statements from CloudShell
