gsutil cp train_and_apply.py gs://$DEVSHELL_PROJECT_ID
