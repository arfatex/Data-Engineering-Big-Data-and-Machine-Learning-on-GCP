#Create a trained model and apply it to all the users in the system.
#Your data science team has created a recommendation model using Apache Spark and is written in Python

gsutil cp gs://cloud-training/bdml/v2.0/model/train_and_apply.py train_and_apply.py
cloudshell edit train_and_apply.py
