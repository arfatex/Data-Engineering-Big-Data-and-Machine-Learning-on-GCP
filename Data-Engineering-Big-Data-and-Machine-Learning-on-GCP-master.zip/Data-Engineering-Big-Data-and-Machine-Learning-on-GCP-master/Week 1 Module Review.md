1.
Question 1
What are the common big data challenges that you will be building solutions for in this course? (check all that apply)

1 / 1 point

Migrating existing on-premise workloads to the cloud -->Correct



Analyzing large datasets at scale  -->Correct



Building containerized applications for web development


Building streaming data pipelines  -->Correct



Applying machine learning to your datasets  -->Correct

Correct
2.
Question 2
You have a large enterprise that will likely have many teams using their own Google Cloud Platform 
projects and resources. What should you be sure to have to help manage and administer these resources?
(check all that apply)

0 / 1 point

A defined Organization  -->Correct


Folders for teams and/or products-->Correct


A defined access control policy with Cloud IAM  -->Correct


A Kubernetes or Hadoop cluster for each project

You didn’t select all the correct answers
3.
Question 3
Which of the following is NOT one of the advantages of Google Cloud security

0 / 1 point

Google Cloud will automatically manage and curate your content and access policies to be safe 

for the public --> Correct - this is your responsibility

Google Cloud will secure the physical hardware that is running your applications and infrastructure


Google Cloud has tools like Cloud IAM that help you administer and set company-wide security policies


Google Cloud will manage audit logging of access and use of resources in your account


4.
Question 4
If you don't have a large dataset of your own but still want to practice writing queries and building pipelines on Google Cloud Platform, what should you do?

1 / 1 point

Practice with the datasets in the Google Cloud Public Datasets program  -->Correct


Find other public datasets online and upload them into BigQuery  -->Correct


Work to create your own dataset and then upload it into BigQuery for analysis  -->Correct


5.
Question 5
As you saw in the demo, Compute Engine nodes on GCP are:

1 / 1 point

Pre-installed with all the software packages you might ever need.


One of ~50 choices in terms of CPU and memory


Allocated on demand, and you pay for the time that they are up. -->Correct


Expensive to create and teardown 

